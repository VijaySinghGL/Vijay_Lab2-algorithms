module lab2Assignment {
}